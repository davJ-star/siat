import todo.view.TodoView;

public class TodoFrontMain {
    public static void main(String[] args) {
        TodoView view = new TodoView() ; 
        view.menu(); 
    }
}
